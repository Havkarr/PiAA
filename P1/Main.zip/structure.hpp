#pragma once
#include <string>
#include <vector>

struct movie
{
    std::string title;
    float grade;
};

